<?php $i=1; ?>
        <?php $__currentLoopData = $usersinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      <td><?php echo e($i); ?></td>
        <td><?php echo e($userdata->name); ?></td>
        <td><?php echo e($userdata->email); ?></td>
      </tr>
      
      <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\xampp\htdocs\mtest\resources\views/subusers.blade.php ENDPATH**/ ?>